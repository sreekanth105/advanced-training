package assaignment1;

public class MainClass_1_3_2 {
	
	public void createBooks() {
		Book_1_3_1 bk[] = new Book_1_3_1[2];		 
	      bk[0] = new Book_1_3_1("Java Programing ", 350.50);
	      bk[1] = new Book_1_3_1("Let Us C", 200.00);
	      for(int i = 0; i<bk.length; i++) {
		         bk[i].display();
		         System.out.println(" ");
	      }
	    
	      }
	
	public void showBooks() {
		  	createBooks();
		
	}
	public static void main(String args[])  {
	    MainClass_1_3_2 c1 = new MainClass_1_3_2();  
		c1.showBooks();
	   
	      }
	   }


