package assaignment8;
public class Counter_8_1 implements  Runnable{
       
      public static void main(String[] args) {
            Storag store = new Storag();
            Printe p1 = new Printe(store);
            Counter_8_1 c1 = new Counter_8_1(store);
      }
      Storag st;
      public Counter_8_1(Storag store){
            st = store;
            new Thread(this, "Counter").start();
             
      }
      @Override
      public void run() {
            for(int i = 0 ; i < 10; i++){
        synchronized (st) {
                  st.setValue(i);
                  st.notify();
                  try {
                    st.wait();
                  }catch(InterruptedException ie) { System.err.println("Interrupted - " + ie.getMessage()); }
        }
            }
             
      }
 
}
class Printe implements Runnable{
      Storag st;
      public Printe(Storag st){
            this.st = st;
            new Thread(this, "Printer").start();
      }
      @Override
      public void run() {
          int counter = 0;
          synchronized (st) {
            while (counter < 9) {
            try {
              st.wait();
            }
            catch(InterruptedException ie) { System.err.println("Interrupted - " + ie.getMessage()); }
            System.out.println(Thread.currentThread().getName() + " " + (counter=st.getValue()));
            st.notify();
            }
          }
      }
       
}
class Storag{
  
      int  i;
      public synchronized void setValue(int i){   //note these method names do not follow 
            this.i = i;                           //javabean naming standard
      }
      public synchronized int getValue(){
            return this.i;
      }
}